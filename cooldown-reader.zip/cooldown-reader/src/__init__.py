# Cooldown Reader - MMO Action Bar Cooldown Detection
