from .screen_capture import ScreenCapture

__all__ = ["ScreenCapture"]
